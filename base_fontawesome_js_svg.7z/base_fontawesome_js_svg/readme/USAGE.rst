Now, all free icons from `Font Awesome <https://fontawesome.com/icons?d=gallery&m=free>`_
can be used on odoo. It also adds three options in order to add the icons:
* solid_icon
* regular_icon
* brand_icon
The usage depends on the configuration of the icon.

For example, brand_icon is necessary if we are using an icon of a brand::

    <button brand_icon="fa-amazon-pay"/>
