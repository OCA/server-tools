This module adds a security group to restrict importation of users
to members of this specific group.
